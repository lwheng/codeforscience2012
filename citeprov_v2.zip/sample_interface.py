import citprov

predictor = citprov.citprov()
output = predictor.predict("my_model", "my_query")
print output
